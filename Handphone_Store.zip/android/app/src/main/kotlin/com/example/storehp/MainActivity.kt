package com.example.storehp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
